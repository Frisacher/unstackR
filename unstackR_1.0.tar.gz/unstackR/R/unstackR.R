#' @title Split and merge data frames
#' @author Florent Risacher
#' @description
#' \code{unstackR} Split then merge a data frame by a factor with different length
#' 
#' Function that subsets the data frame into multiple ones by a chosen factor
#' The data frames are then merge using common columns
#' @param x A data frame 
#' @param split.by Name of the column to use for splitting as a character string.
#' @param merge.by Name of the column(s) to use for merging as a character string.
#' @param name Name of the variable that will be duplicated and need to be rename by the factor level use to split.
#' @param ... Arguments passed from other methods
#' 
#' @details 
#' unstackR is a simple function that splits data frames by a factor to merge them again by another factor or variable.
#' The function uses the split and merge function provided un base R. Methods for these two function can be consulted for more information.
#' 
#' The arguments split.by and merge.by must be provided as a character string. It is possible to merge using multiple columns by providing a list of column names such as c().
#' 
#' If the columns in the data frames not used in merging have any common names, these have suffixes (".x" and ".y" by default) appended to try to make the names of the result unique. If this is not possible, an error is thrown.
#' The argument name is used for renaming the variable that will be duplicated and need to be renamed using the level of the factor use to split. This argument is used so suffixes are not use as mentioned above and each column is correctly labeled.
#' 
#' @examples  
#' value<-c(4,2,6,8,0)
#' variable<-c(1,2,1,3,1)
#' y<-c('a','a','b','a','c')
#' df<- data.frame(value,variable,y)
#' 
#' unstackR(df, split.by= "y", merge.by= "variable", name= "value")
#' 
#' @seealso 
#' \url{https://github.com/Frisacher/unstackR}

#' @export
unstackR<-function(x, split.by, merge.by, name ,...)
{
  #split
  data.frame.list<-split(x, f=x[,split.by])
  
  #drop extra variable
  data.frame.list <- lapply(data.frame.list, function(x) x[!(names(x) %in% as.character(split.by))])
  
  #rename the 'y' variable in the list of data frames using a loop
  for (i in seq_along(data.frame.list))
    {
     names(data.frame.list[[i]])[names(data.frame.list[[i]])==name] <- levels(x[,split.by])[i]
    }
  
  #merge
  Reduce(function(x, y) merge(x, y,by=merge.by, all=TRUE), data.frame.list)

}